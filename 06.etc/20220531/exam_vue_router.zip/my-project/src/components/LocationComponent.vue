<template>
<div class="location subpage">
  <main>
    <!-- 컨텐츠영역 -->
    <div class="container">
      <aside id="lnb">
        <ul>
          <li><router-link to='location'>Location</router-link></li>
        </ul>
      </aside>
      <div class="content">
        <h2 class="sub-title"><span>Location</span></h2>
        <div class="inner">
          <div id="map" style="width: 1000px; height: 350; margin: 50px auto 0;"></div>
        </div>
      </div>
    </div>
  </main>
</div>
</template>

<script>
export default {
  name: 'location-component',
  data() {
    return {
      msg: 'this is location component'
    }
  }
}
</script>
<style>
</style>
