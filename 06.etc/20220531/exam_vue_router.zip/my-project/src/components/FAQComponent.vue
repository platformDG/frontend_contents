<template>
<div class="faq subpage">
  <main>
    <!-- 컨텐츠영역 -->
    <div class="container">
      <aside id="lnb">
        <ul>
          <li><router-link to='notice'>Notice</router-link></li>
          <li><router-link to='faq'>FAQ</router-link></li>
        </ul>
      </aside>
      <div class="content">
        <h2 class="sub-title"><span>FAQ</span></h2>
        <div class="inner">
          <div class="accordion">
            <dl>
              <dt>Step.1</dt>
              <dd>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
              </dd>
              <dt>Step.2</dt>
              <dd>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
              </dd>
              <dt>Step.3</dt>
              <dd>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
              </dd>
            </dl>
          </div>
        </div>
      </div>
    </div>
  </main>
</div>
</template>

<script>
export default {
  name: 'faq-component',
  data() {
    return {
      msg: 'this is faq component'
    }
  }
}
</script>
<style>
</style>
