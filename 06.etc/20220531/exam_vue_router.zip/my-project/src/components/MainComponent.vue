<template>
<div class="main">
  <main>
    <!-- 메인배너 -->
    <div class="mainbanner"></div>
    <!-- 컨텐츠영역 -->
    <div class="container">
      <div class="content">
        <div class="inner">
          <div class="box items_2">
            <div class="items">
              <h3 class="title">funiture</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
              <a href="./company/introduce.html" class="gbtn">More View</a>
            </div>
            <div class="items">
              <img src="@/assets/img/thumb_nail01.jpg" alt="funiture01">
            </div>
          </div>
          <div class="box items_2">
            <div class="items">
              <img src="@/assets/img/thumb_nail02.jpg" alt="funiture02">
            </div>
            <div class="items">
              <h3 class="title">funiture</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
              <a href="./company/introduce.html" class="gbtn">More View</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
</div>
</template>

<script>
export default {
  name: 'main-component',
  data() {
    return {
      msg: 'this is main component'
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style >

</style>
