<template>
<div class="ci subpage">
  <main>
    <!-- 컨텐츠영역 -->
    <div class="container">
      <aside id="lnb">
        <ul>
          <li><router-link to='introduce'>Introduce</router-link></li>
          <li><router-link to='ci'>CI</router-link></li>
          <li><router-link to='history'>History</router-link></li>
        </ul>
      </aside>
      <div class="content">
        <h2 class="sub-title"><span>CI</span></h2>
        <div class="inner">
          <div class="box">
            <div class="items">
              <h3 class="title">funiture</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
            </div>
            <div class="items">
              <img src="@/assets/img/company/company_img01.jpg" alt="fcompany_img01">
            </div>
          </div>
        </div>
        <div class="inner">
          <div class="box">
            <div class="items">
              <img src="@/assets/img/company/company_img02.jpg" alt="fcompany_img02">
            </div>
            <div class="items">
              <h3 class="title">funiture</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
</div>
</template>

<script>
export default {
  name: 'ci-component',
  data() {
    return {
      msg: 'this is ci component'
    }
  }
}
</script>
<style>
</style>
