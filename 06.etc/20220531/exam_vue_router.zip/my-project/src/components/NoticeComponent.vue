<template>
<div class="notice subpage">
  <main>
    <!-- 컨텐츠영역 -->
    <div class="container">
      <aside id="lnb">
        <ul>
          <li><router-link to='notice'>Notice</router-link></li>
          <li><router-link to='faq'>FAQ</router-link></li>
        </ul>
      </aside>
      <div class="content">
        <h2 class="sub-title"><span>Notice</span></h2>
        <div class="inner">
          <section>
            <div class="tbl-header">
              <table>
                <thead>
                  <tr>
                    <th>Code</th>
                    <th>Company</th>
                    <th>Price</th>
                    <th>Change</th>
                    <th>Change % </th>
                  </tr>
                </thead>
              </table>
            </div>
            <div class="tbl-content">
              <table>
                <tbody>
                  <tr>
                    <td>ACC</td>
                    <td>AUTRAINMAM</td>
                    <td>$1.38</td>
                    <td>+0.01</td>
                    <td>-0.36%</td>
                  </tr>
                  <tr>
                    <td>AAD</td>
                    <td>AUSENCO</td>
                    <td>$2.38</td>
                    <td>-0.01</td>
                    <td>-1.36%</td>
                  </tr>
                  <tr>
                    <td>AAX</td>
                    <td>AELAIDE</td>
                    <td>$3.21</td>
                    <td>+0.01</td>
                    <td>+1.36%</td>
                  </tr>
                  <tr>
                    <td>AAX</td>
                    <td>AELAIDE</td>
                    <td>$3.21</td>
                    <td>+0.01</td>
                    <td>+1.36%</td>
                  </tr>
                  <tr>
                    <td>AAX</td>
                    <td>AELAIDE</td>
                    <td>$3.21</td>
                    <td>+0.01</td>
                    <td>+1.36%</td>
                  </tr>
                  <tr>
                    <td>AAX</td>
                    <td>AELAIDE</td>
                    <td>$3.21</td>
                    <td>+0.01</td>
                    <td>+1.36%</td>
                  </tr>
                  <tr>
                    <td>AAD</td>
                    <td>AUSENCO</td>
                    <td>$2.38</td>
                    <td>-0.01</td>
                    <td>-1.36%</td>
                  </tr>
                  <tr>
                    <td>AAD</td>
                    <td>AUSENCO</td>
                    <td>$2.38</td>
                    <td>-0.01</td>
                    <td>-1.36%</td>
                  </tr>
                  <tr>
                    <td>ACC</td>
                    <td>AUTRAINMAM</td>
                    <td>$1.38</td>
                    <td>+0.01</td>
                    <td>-0.36%</td>
                  </tr>
                  <tr>
                    <td>ACC</td>
                    <td>AUTRAINMAM</td>
                    <td>$1.38</td>
                    <td>+0.01</td>
                    <td>-0.36%</td>
                  </tr>
                  <tr>
                    <td>ACC</td>
                    <td>AUTRAINMAM</td>
                    <td>$1.38</td>
                    <td>+0.01</td>
                    <td>-0.36%</td>
                  </tr>
                  <tr>
                    <td>AAD</td>
                    <td>AUSENCO</td>
                    <td>$2.38</td>
                    <td>-0.01</td>
                    <td>-1.36%</td>
                  </tr>
                  <tr>
                    <td>AAX</td>
                    <td>AELAIDE</td>
                    <td>$3.21</td>
                    <td>+0.01</td>
                    <td>+1.36%</td>
                  </tr>
                  <tr>
                    <td>AAX</td>
                    <td>AELAIDE</td>
                    <td>$3.21</td>
                    <td>+0.01</td>
                    <td>+1.36%</td>
                  </tr>
                  <tr>
                    <td>AAX</td>
                    <td>AELAIDE</td>
                    <td>$3.21</td>
                    <td>+0.01</td>
                    <td>+1.36%</td>
                  </tr>
                  <tr>
                    <td>AAX</td>
                    <td>AELAIDE</td>
                    <td>$3.21</td>
                    <td>+0.01</td>
                    <td>+1.36%</td>
                  </tr>
                  <tr>
                    <td>AAD</td>
                    <td>AUSENCO</td>
                    <td>$2.38</td>
                    <td>-0.01</td>
                    <td>-1.36%</td>
                  </tr>
                  <tr>
                    <td>AAD</td>
                    <td>AUSENCO</td>
                    <td>$2.38</td>
                    <td>-0.01</td>
                    <td>-1.36%</td>
                  </tr>
                  <tr>
                    <td>ACC</td>
                    <td>AUTRAINMAM</td>
                    <td>$1.38</td>
                    <td>+0.01</td>
                    <td>-0.36%</td>
                  </tr>
                  <tr>
                    <td>ACC11</td>
                    <td>AUTRAINMAM</td>
                    <td>$1.38</td>
                    <td>+0.01</td>
                    <td>-0.36%</td>
                  </tr>
                </tbody>
              </table>
              <a href="#" class="gbtn right">write</a>
            </div>
          </section>
        </div>
      </div>
    </div>
  </main>
</div>
</template>

<script>
export default {
  name: 'notice-component',
  data() {
    return {
      msg: 'this is notice component'
    }
  }
}
</script>
<style>
</style>
