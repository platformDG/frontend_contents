<template>
  <header id="header">
    <!-- 로고 -->
    <h1 id="top-logo">
      <router-link to='/'>XWOOD</router-link>
    </h1>
    <!-- 메인메뉴 -->
    <nav id="top-nav">
      <ul>
        <!--
          실습1:
          아래 li 메뉴 리스트를 v-for를 사용하여 출력하시오.
          (메뉴 리스트는 href, text를 data로 생성하여 menuList 배열에 담고 반복문으로 출력.)
        -->
        <li v-for='(list, i) in menuList'>
          <router-link v-bind:to='list.path'>{{list.text}}</router-link>
          <!-- Company submenu -->
          <ul v-if="i == 0" class="sub-menu">
            <li v-for='cslist in companySubmenu' >
              <router-link v-bind:to='cslist.path'>{{cslist.text}}</router-link>
            </li>
          </ul>
          <!-- Community submenu -->
          <ul v-if="i == 3" class="sub-menu">
            <li v-for='cmlist in communitySubmenu' >
              <router-link v-bind:to='cmlist.path'>{{cmlist.text}}</router-link>
            </li>
          </ul>
        </li>

        <!-- <li>
          <router-link to='introduce'>Company</router-link>
          <ul class="sub-menu">
            <li><router-link to='introduce'>Introduce</router-link></li>
            <li><router-link to='ci'>CI</router-link></li>
            <li><router-link to='history'>History</router-link></li>
          </ul>
        </li>
        <li><router-link to='product'>Product</router-link></li>
        <li><router-link to='gallery'>Gallery</router-link></li>
        <li>
          <router-link to='notice'>Community</router-link>
          <ul class="sub-menu">
            <li><router-link to='notice'>Notice</router-link></li>
            <li><router-link to='faq'>FAQ</router-link></li>
          </ul>
        </li>
        <li><router-link to='location'>Location</router-link></li> -->
      </ul>
    </nav>
  </header>
</template>

<script>
export default {
  name: 'header-component',
  data() {
    return {
      msg: 'header-component',
      menuList : [
        { path: '/introduce', text:'Company' },
        { path: '/product', text:'Product' },
        { path: '/gallery', text:'Gallery' },
        { path: '/notice', text:'Community' },
        { path: '/location', text:'Location' }
      ],
      companySubmenu : [
        { path: '/introduce', text:'Introduce' },
        { path: '/ci', text:'CI' },
        { path: '/history', text:'History' },
      ],
      communitySubmenu : [
        { path: '/notice', text:'Notice' },
        { path: '/faq', text:'FAQ' },

      ]
    }
  }
}
</script>

<style>
</style>
