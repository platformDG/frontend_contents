<template>
  <footer id="footer">
    <!-- footer 상단영역 -->
    <div class="footer-top">
      <div class="container">
        <div class="row">
          <div class="column footer-logo">
            <!-- footer logo -->
            <h3>Logo</h3>
          </div>
          <div class="column">
            <!-- site map -->
            <h4>site map</h4>
            <ul>
              <li v-for="list in menuList">
                <router-link v-bind:to="list.path">{{list.text}}</router-link>
              </li>
              <!-- <li><router-link to='introduce'>Company</router-link></li>
              <li><router-link to='product'>Product</router-link></li>
              <li><router-link to='gallery'>Gallery</router-link></li>
              <li><router-link to='notice'>Community</router-link></li>
              <li><router-link to='location'>Location</router-link></li> -->
            </ul>
          </div>
          <div class="column">
            <!-- contact us -->
            <h4>contact us</h4>
            <p>
              A108 Adam street<br>
              New York, Ny 535022<br>
              United states<br>
              <strong>Phone :</strong> <a href="tel:+82-10-1111-1111">+82-10-1111-1111</a><br>
              <strong>Email :</strong> <a href="mailto:mymail@naver.com">mymail@naver.com</a>
            </p>
          </div>
          <div class="column news">
            <!-- news -->
            <h4>news</h4>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
            <form>
              <input type="text" name="search"><input type="submit" value="search">
            </form>
          </div>
        </div>
      </div>
    </div>
    <!-- footer 하단영영 -->
    <div class="container">
      <div class="copyright">
        &copy;copyright <strong>MyPage</strong> .All Rights Reserved.
      </div>
      <div class="credits">
        Designed By <a href="mailto:aaa@naver.com">MySelf</a>
      </div>
    </div>
  </footer>
</template>

<script>
export default {
  name: 'footer-component',
  data() {
    return {
      msg: 'footer-component',
      menuList : [
        { path: '/introduce', text:'Company' },
        { path: '/product', text:'Product' },
        { path: '/gallery', text:'Gallery' },
        { path: '/notice', text:'Community' },
        { path: '/location', text:'Location' }
      ]
    }
  }
}
</script>
<style>
</style>
